# Processor capability checks
#
# Copyright © 2015 Open Microscopy Environment / University of Dundee
# Copyright © 2021 Roger Leigh <rleigh@codelibre.net>
# Written by Roger Leigh <rleigh@codelibre.net>
#
# Permission to use, copy, modify, distribute, and sell this software and
# its documentation for any purpose is hereby granted without fee, provided
# that (i) the above copyright notices and this permission notice appear in
# all copies of the software and related documentation, and (ii) the names of
# Sam Leffler and Silicon Graphics may not be used in any advertising or
# publicity relating to the software without the specific, prior written
# permission of Sam Leffler and Silicon Graphics.
#
# THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
# EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
# WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
#
# IN NO EVENT SHALL SAM LEFFLER OR SILICON GRAPHICS BE LIABLE FOR
# ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
# OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF
# LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.


# CPU endianness
# Use CMAKE_C_BYTE_ORDER if available, otherwise fall back to test_big_endian()
if(DEFINED CMAKE_C_BYTE_ORDER)
    if(CMAKE_C_BYTE_ORDER STREQUAL "BIG_ENDIAN")
        set(WORDS_BIGENDIAN TRUE)
        set(HOST_BIG_ENDIAN 1)
    else()
        set(WORDS_BIGENDIAN FALSE)
        set(HOST_BIG_ENDIAN 0)
    endif()
else()
    include(TestBigEndian)
    test_big_endian(WORDS_BIGENDIAN)
    if(WORDS_BIGENDIAN)
        set(HOST_BIG_ENDIAN 1)
    else()
        set(HOST_BIG_ENDIAN 0)
    endif()
endif()

# IEEE floating point
set(HAVE_IEEEFP 1)
